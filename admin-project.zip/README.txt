MasterX Admin (separate app)
============================
Same build steps as the main MasterX app:
  npm install
  npx cap add android
  npx @capacitor/assets generate --android   (uses resources/icon.png + splash)
  npx cap sync android
then build the APK (Android Studio or your usual build).

First run: paste your Firebase Realtime Database URL (the same one used in MasterX),
then create the admin password. Keep this APK private - do not share it with users.
