MasterX Admin (වෙනම app එකක්)
==============================
GitHub වලින් APK හදන හැටි:
1. GitHub එකේ අලුත් PRIVATE repo එකක් හදන්න (MasterX repo එකෙන් වෙනම).
2. මේ zip එකේ ඇති සියල්ල upload කරන්න. .github folder එකත් ඇතුළුව
   (phone එකෙන් .github පේන්නේ නැත්නම්: Add file > Create new file,
   නම විදිහට  .github/workflows/build-admin-apk.yml  ටයිප් කරලා
   build-admin-apk.yml file එකේ content paste කරන්න).
3. Actions tab > "Build MasterX Admin APK" > Run workflow.
4. ඉවර වුණාම පහළ Artifacts > MasterX-Admin-APK download කරලා unzip කරන්න. ඇතුළේ app-debug.apk.
5. Install කරන්න. ("Install unknown apps" allow කරන්න ඕන.)

පළමු වතාවට open කරද්දී: Firebase Realtime Database URL එක paste කරලා admin password එකක් හදන්න.
මේ APK එක ඔයාගේම පාවිච්චියට විතරයි.
