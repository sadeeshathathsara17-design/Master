/* MasterX Store shared helpers (used by store.html and admin.html)
   Paste your Firebase Realtime Database URL below, or connect it inside the app (Profile > Database). */
window.STORE_DB_URL = window.STORE_DB_URL || "";
(function(W){
  function ls(k){try{return localStorage.getItem(k)}catch(e){return null}}
  function dbUrl(){var u=W.STORE_DB_URL||W.MX_DB_URL;if(!u){try{u=JSON.parse(ls('mxc_data')).s.db}catch(e){}}return String(u||'').trim().replace(/\/+$/,'')}
  function online(){return !!dbUrl()}
  function dbx(method,path,body,q){
    var c=new AbortController(),tm=setTimeout(function(){c.abort()},15000);
    return fetch(dbUrl()+'/store/'+path+'.json'+(q||''),{method:method,body:body!==undefined?JSON.stringify(body):undefined,signal:c.signal})
      .then(function(r){clearTimeout(tm);if(!r.ok)throw new Error('HTTP '+r.status);return r.json()})
      .catch(function(e){clearTimeout(tm);throw e});
  }
  function setDb(u){var d={};try{d=JSON.parse(ls('mxc_data'))||{}}catch(e){}d.s=d.s||{};d.s.db=u;try{localStorage.setItem('mxc_data',JSON.stringify(d))}catch(e){}}
  /* pure-JS SHA-256 fallback (when crypto.subtle is not available) */
  function sha256js(ascii){
    function rr(v,a){return (v>>>a)|(v<<(32-a))}
    var mp=Math.pow,mw=mp(2,32),i,j,result='',words=[],al=ascii.length*8,hash=[],k=[],pc=0,ic={};
    for(var c=2;pc<64;c++){if(!ic[c]){for(i=0;i<313;i+=c)ic[i]=c;hash[pc]=(mp(c,.5)*mw)|0;k[pc++]=(mp(c,1/3)*mw)|0}}
    hash=hash.slice(0,8);
    ascii+='\x80';while(ascii.length%64-56)ascii+='\x00';
    for(i=0;i<ascii.length;i++){j=ascii.charCodeAt(i);if(j>>8)return;words[i>>2]|=j<<((3-i)%4)*8}
    words[words.length]=((al/mw)|0);words[words.length]=al;
    for(j=0;j<words.length;){var w=words.slice(j,j+=16),oh=hash;hash=hash.slice(0,8);
      for(i=0;i<64;i++){var w15=w[i-15],w2=w[i-2],a=hash[0],e=hash[4];
        var t1=hash[7]+(rr(e,6)^rr(e,11)^rr(e,25))+((e&hash[5])^((~e)&hash[6]))+k[i]+(w[i]=(i<16)?w[i]:(w[i-16]+(rr(w15,7)^rr(w15,18)^(w15>>>3))+w[i-7]+(rr(w2,17)^rr(w2,19)^(w2>>>10)))|0);
        var t2=(rr(a,2)^rr(a,13)^rr(a,22))+((a&hash[1])^(a&hash[2])^(hash[1]&hash[2]));
        hash=[(t1+t2)|0].concat(hash);hash[4]=(hash[4]+t1)|0}
      for(i=0;i<8;i++)hash[i]=(hash[i]+oh[i])|0}
    for(i=0;i<8;i++)for(j=3;j+1;j--){var b=(hash[i]>>(j*8))&255;result+=((b<16)?0:'')+b.toString(16)}
    return result;
  }
  function sha(str){
    if(W.crypto&&W.crypto.subtle&&W.TextEncoder){
      return W.crypto.subtle.digest('SHA-256',new TextEncoder().encode(str)).then(function(b){return Array.from(new Uint8Array(b)).map(function(x){return x.toString(16).padStart(2,'0')}).join('')});
    }
    return Promise.resolve(sha256js(unescape(encodeURIComponent(str))));
  }
  async function hashPw(pw,salt){var h=await sha(salt+':'+pw);for(var i=0;i<1200;i++)h=await sha(h+salt);return h}
  function newSalt(){var a=new Uint8Array(12);if(W.crypto&&W.crypto.getRandomValues)W.crypto.getRandomValues(a);else for(var i=0;i<12;i++)a[i]=Math.floor(Math.random()*256);return Array.from(a).map(function(x){return x.toString(16).padStart(2,'0')}).join('')}
  /* Sri Lankan numbers -> international format for wa.me */
  function waNum(p){var d=String(p||'').replace(/\D/g,'');if(d.indexOf('94')===0&&d.length>=11)return d;if(d.charAt(0)==='0')return '94'+d.slice(1);if(d.length===9)return '94'+d;return d}
  W.MXS={dbUrl:dbUrl,online:online,dbx:dbx,setDb:setDb,sha:sha,sha256js:sha256js,hashPw:hashPw,newSalt:newSalt,waNum:waNum};
})(window);
