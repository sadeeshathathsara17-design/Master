// MasterX optional config (index.html has built-in defaults)
