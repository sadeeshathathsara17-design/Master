/* MasterX server settings. Server ekak thiyenawanam URL eka methana danna (ex: "https://masterx.example.com") */
window.MX_API_BASE = "";
(function(){
  var B = window.MX_API_BASE; if(!B) return;
  B = B.replace(/\/$/, "");
  var f = window.fetch;
  window.fetch = function(u, o){
    if(typeof u === "string" && u.charAt(0) === "/"){ u = B + u; o = Object.assign({}, o, {credentials:"include"}); }
    return f.call(this, u, o);
  };
})();
