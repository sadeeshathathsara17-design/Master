module.exports = {
  content: ["./www/**/*.html"],
  theme: { extend: {} },
  plugins: [],
};
